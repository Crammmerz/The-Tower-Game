extends Area2D

@export var target_portal: Area2D
var can_teleport: bool = true

@onready var cooldown_timer = $CoolDownTimer
@onready var cooldown_bar = $CoolDownBar

func _ready():
	body_entered.connect(_on_body_entered)
	cooldown_timer.timeout.connect(_on_cooldown_timeout)
	print("Portal ready at: ", global_position, " name: ", name)

func _process(_delta):
	if not cooldown_timer.is_stopped():
		cooldown_bar.value = cooldown_timer.time_left

func _on_body_entered(body):
	if body.name == "Player" and can_teleport and is_instance_valid(target_portal):
		target_portal.start_cooldown()
		var landing = target_portal.get_node("LandingSpot")
		body.global_position = landing.global_position
		print("Landing at: ", landing.global_position)
		start_cooldown()

func start_cooldown():
	can_teleport = false
	cooldown_timer.start()
	cooldown_bar.visible = true

func _on_cooldown_timeout():
	can_teleport = true
	cooldown_bar.visible = false
